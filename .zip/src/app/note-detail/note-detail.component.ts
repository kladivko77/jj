import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { Location } from '@angular/common';

import { Note } from '../note';
import { NoteService } from '../note.service';



@Component({
  selector: 'app-note-detail',
  templateUrl: './note-detail.component.html',
  styleUrls: [ './note-detail.component.css' ]
})

export class NoteDetailComponent implements OnInit {
  note: Note;
  notes: Note[] = [];

  constructor(
    private route: ActivatedRoute,
    private noteService: NoteService,
    private location: Location,
    private routerService:Router,
  ) {}

  ngOnInit(): void {
    this.getNote();
  }

  getNote(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.noteService.getNote(id)
      .subscribe(note => this.note = note);
  }

  goBack(): void {
    this.location.back();
  }

  save(): void {
    this.noteService.updateNote(this.note)
      .subscribe(() => this.goBack());
  }

  goDelete(note: Note): void {
    this.notes = this.notes.filter(h => h !== note);
    this.noteService.deleteNote(note).subscribe();
    this.routerService.navigate(['main']);
  }
}
