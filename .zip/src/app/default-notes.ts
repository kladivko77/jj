import { Note } from './note';

export const NOTES: Note[] = [
  { id: 1, name: 'Seznam nákupu', body: 'Chleba, 1Ox rohlík, šunka, sýr, kuřecí maso, rýže, 1kg brambory'},
  { id: 2, name: 'Narozeniny', body: '10.08. - Brácha, 23.11. - Taťka 14.12. - Mamka'},
  { id: 3, name: 'Svátky', body: '09.08 - Brácha, 20.10. - Taťka 09.11. - Strýc Bohdan'},
  { id: 4, name: 'Sousedící státy', body: 'Slovensko, Polsko, Rakousko, Německo'},
  { id: 5, name: 'Vtip, který mi vyprávěl nejlepší kamarád' , body: 'Přijde pán k lékaři a říká mu: „Pane doktore, jeli jsme k moři a neviděli jsme ho.“ \n' +
      'Doktor se zamyslí a povídá: „Tak jste měli jet ještě blíž.“'},
  { id: 6, name: 'Věci které musím stihnout ještě dnes, než půjdu zítra do školy', body: 'Udělat úkoly' },
  { id: 7, name: 'Nápady', body: 'Jednou bych chtěl dostat opravdu dobrý nápad' },
  { id: 8, name: 'Definice Vlka obecného', body: 'Vlk obecný je velká psovitá šelma. Postupná domestikace tohoto druhu vedla k vydělení poddruhu Canis lupus familiaris – psa domácího' },
  { id: 9, name: 'Seznam nejlepších kamarádů', body: 'Pavel, Jirka, Petr, Lukáš, Verča' },
  { id: 10, name: 'Hezká jména', body: 'Natalie, Zuzka, Petr, Lukáš, Verča, Patrik, Nikola' },

];
