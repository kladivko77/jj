import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NoteService } from '../note.service';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: [ './main.component.css' ]
})
export class MainComponent implements OnInit {
  notes: Note[] = [];

  constructor(private noteService: NoteService) { }



  ngOnInit() {
    this.getNotes();
  }

  getNotes(): void {
    this.noteService.getNotes()
      .subscribe(notes => this.notes = notes.slice(0, 100));
  }

  delete(event, note: Note): void {
    event.preventDefault();
    this.notes = this.notes.filter(h => h !== note);
    this.noteService.deleteNote(note).subscribe();
  }

  add(name: string, body: string): void {
    name = name.trim();
    if (!name) { return; }
    this.noteService.addNotes({ name: name, body: body } as Note)
      .subscribe(note => {
        this.notes.push(note);
      });
  }
}
