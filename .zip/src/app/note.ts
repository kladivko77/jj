export interface Note {
  id: number;
  name: string;
  body?: string;
}
