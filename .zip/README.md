# Josef Gargulák - Notes App
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.1.3
## Install packages
Run `npm install`
## Development server
Run `ng serve --port 4000` for a dev server. Navigate to `http://localhost:4000/`.
